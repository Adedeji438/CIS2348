string_input = input()
str_array = string_input.split(" ")
for s in str_array:
    print(s,str_array.count(s))